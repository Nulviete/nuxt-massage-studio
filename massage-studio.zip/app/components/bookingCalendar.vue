<!-- components/BookingCalendar.vue -->
<script setup lang="ts">
import { shallowRef, ref, watch, onMounted, computed } from "vue";
import { CalendarDate } from "@internationalized/date";

const {
  public: { apiBase },
} = useRuntimeConfig();

const props = defineProps(["user"]);

// model kalendáře
const today = new Date();
const modelValue = shallowRef(
  new CalendarDate(today.getFullYear(), today.getMonth() + 1, today.getDate())
);

// stav a data
const eventsByDate = ref<
  Record<
    string,
    {
      id: string;
      summary: string;
      start: string;
      end: string;
      allDay: boolean;
    }[]
  >
>({});
const selectedDate = ref<Date>(new Date());
const loading = ref(false);

const deletingId = ref<string | null>(null);

async function cancelMyBooking(s: { eventId?: string; my?: boolean }) {
  if (!s?.my || !s?.eventId) return;
  if (!window.confirm("Opravdu zrušit tuto rezervaci?")) return;

  deletingId.value = s.eventId;
  try {
    await $fetch(`${apiBase}/api/my-events/${s.eventId}`, { method: "DELETE" });
    await loadEvents();
  } catch (e) {
    console.error(e);
  } finally {
    deletingId.value = null;
  }
}

function isoKey(d: Date) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function monthRangeAround(now = new Date()) {
  const start = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const end = new Date(now.getFullYear(), now.getMonth() + 2, 0, 23, 59, 59);
  return { timeMin: start.toISOString(), timeMax: end.toISOString() };
}

async function loadEvents() {
  loading.value = true;
  try {
    const { timeMin, timeMax } = monthRangeAround(selectedDate.value);
    const res = await $fetch<{ items: any[] }>(`${apiBase}/api/events`, {
      params: { timeMin, timeMax },
    });
    const map: Record<string, any[]> = {};
    for (const e of res.items || []) {
      const s = new Date(e.start);
      const eend = new Date(e.end);
      for (
        let d = new Date(s.getFullYear(), s.getMonth(), s.getDate());
        d <=
        new Date(
          eend.getFullYear(),
          eend.getMonth(),
          eend.getDate() - (e.allDay ? 1 : 0)
        );
        d.setDate(d.getDate() + 1)
      ) {
        const key = isoKey(d);
        if (!map[key]) map[key] = [];
        map[key].push(e);
      }
    }
    eventsByDate.value = map;
  } finally {
    loading.value = false;
  }
}

function hasFreeSlotOnDate(date: Date) {
  // všechny eventy pro daný den
  const dayKey = isoKey(date);
  const dayEvs = eventsByDate.value[dayKey] || [];

  // projdi všechny možné sloty v rámci pracovní doby
  for (let h = OPEN_HOUR; h < CLOSE_HOUR; h += STEP_MIN / 60) {
    const slotStart = makeDateAt(date, h);
    const slotEnd = new Date(slotStart.getTime() + STEP_MIN * 60000);

    // je tenhle slot kolizní s nějakým eventem?
    const overlaps = dayEvs.some((e) => {
      const s = new Date(e.start);
      const ee = new Date(e.end);
      return isOverlapping(slotStart, slotEnd, s, ee);
    });

    // jakmile najdeme slot bez kolize, máme volné místo
    if (!overlaps) return true;
  }

  // nenašel se žádný volný slot
  return false;
}

function getColorByDate(date: Date) {
  // zelená (success), pokud existuje aspoň 1 volné místo, jinak červená (error)
  return hasFreeSlotOnDate(date) ? "success" : "error";
}

// Klik na den – UCalendar mění modelValue, tady jen odvodíme JS Date
watch(modelValue, (val) => {
  selectedDate.value = new Date(val.year, val.month - 1, val.day);
});

onMounted(() => {
  selectedDate.value = new Date(
    today.getFullYear(),
    today.getMonth(),
    today.getDate()
  );
  loadEvents();
});

// --- Sloty (např. 9:00–17:00 po 60 min) ---
const OPEN_HOUR = 9;
const CLOSE_HOUR = 17;
const STEP_MIN = 60;

function makeDateAt(date: Date, h: number, m = 0) {
  const d = new Date(
    date.getFullYear(),
    date.getMonth(),
    date.getDate(),
    h,
    m,
    0,
    0
  );
  return d;
}

function isOverlapping(aStart: Date, aEnd: Date, bStart: Date, bEnd: Date) {
  return aStart < bEnd && bStart < aEnd;
}

const dayEvents = computed(
  () => eventsByDate.value[isoKey(selectedDate.value)] || []
);

const slots = computed(() => {
  const out: {
    start: Date;
    end: Date;
    booked: boolean;
    title?: string;
    my?: boolean;
    email?: string | null;
    eventId?: string;
  }[] = [];
  for (let h = OPEN_HOUR; h < CLOSE_HOUR; h += STEP_MIN / 60) {
    const start = makeDateAt(selectedDate.value, h);
    const end = new Date(start.getTime() + STEP_MIN * 60000);
    const ev = dayEvents.value.find((e) => {
      const s = new Date(e.start);
      const ee = new Date(e.end);
      return isOverlapping(start, end, s, ee);
    });
    out.push({
      start,
      end,
      booked: !!ev,
      title: ev?.summary,
      my: ev?.isMine === true,
      email: ev?.email ?? null,
      eventId: ev?.id,
    });
  }
  return out;
});

// --- Rezervační modal ---
const showModal = ref(false);
const modalSlot = ref<{ start: Date; end: Date } | null>(null);
const form = ref({
  name: props.user.user_metadata.name || "",
  email: props.user.email,
  notes: "",
  phone: props.user.user_metadata.phone || "",
  address: props.user.user_metadata.address || "",
});
const submitting = ref(false);

function openBooking(slot: { start: Date; end: Date }) {
  modalSlot.value = slot;
  showModal.value = true;
}

async function submitBooking() {
  if (!modalSlot.value) return;
  submitting.value = true;
  try {
    await $fetch(`${apiBase}/api/bookings`, {
      method: "POST",
      body: {
        name: form.value.name,
        email: form.value.email || undefined,
        notes: form.value.notes || undefined,
        start: modalSlot.value.start.toISOString(),
        end: modalSlot.value.end.toISOString(),
      },
    });
    showModal.value = false;
    form.value = { name: "", email: "", notes: "" };
    await loadEvents();
  } catch (e: any) {
    // může vrátit 409 při kolizi
    console.error(e);
  } finally {
    submitting.value = false;
  }
}
</script>

<template>
  <div class="max-w-xl mx-auto p-4 space-y-4">
    <UCalendar
      v-model="modelValue"
      :disabled="loading"
      :year-controls="false"
      :weekStartsOn="0"
      size="md"
      weekdayFormat="short"
      :fixedWeeks="false"
    >
      <template #day="{ day }">
        <UChip
          :show="!!getColorByDate(day.toDate())"
          :color="getColorByDate(day.toDate())"
          size="2xs"
        >
          {{ day.day }}
        </UChip>
      </template>
    </UCalendar>

    <div class="pt-4">
      <h3 class="text-lg font-medium">
        Dostupné sloty pro {{ selectedDate.toLocaleDateString("pl-PL") }}
      </h3>
      <div class="grid gap-2 mt-2">
        <UCard
          v-for="(s, i) in slots"
          :key="i"
          class="flex flex-col justify-between"
        >
          <div class="flex items-center justify-between">
            <span>
              {{
                s.start.toLocaleTimeString(['pl-PL'], {
                  hour: "2-digit",
                  minute: "2-digit",
                })
              }}–{{
                s.end.toLocaleTimeString(['pl-PL'], {
                  hour: "2-digit",
                  minute: "2-digit",
                })
              }}
            </span>
            <UBadge :color="s.booked ? 'gray' : 'green'">
              {{ s.booked ? "Obsazeno" : "Volné" }}
            </UBadge>
          </div>

          <div v-if="s.booked" class="text-xs mt-1 truncate">
            <template v-if="s.my">
              <UButton
                size="xs"
                color="error"
                variant="soft"
                :loading="deletingId === s.eventId"
                :disabled="deletingId === s.eventId"
                @click="cancelMyBooking(s)"
              >
                Zrušit rezervaci
              </UButton>
              <span v-if="s.email" class="ml-2 text-gray-500"
                >({{ s.email }})</span
              >
            </template>
            <template v-else>
              <span class="opacity-70 text-gray-500">Already Reserved</span>
            </template>
          </div>

          <UButton v-else class="mt-2" @click="openBooking(s)">
            Rezervovat
          </UButton>
        </UCard>
      </div>
    </div>

    <!-- MODAL -->
    <UModal
      v-model:open="showModal"
      title="Potvrdit rezervaci"
      description="Vyplňte prosím údaje a potvrďte rezervaci."
    >
      <template #content>
        <UCard>
          <form @submit.prevent="submitBooking">
            <div class="space-y-3">
              <div class="space-y-1">
                <label class="text-sm font-medium" for="booking-name">
                  Jméno<span class="text-red-500">*</span>
                </label>
                <UInput
                  id="booking-name"
                  v-model="form.name"
                  placeholder="Tvoje jméno"
                  required
                />
              </div>

              <div class="space-y-1">
                <label class="text-sm font-medium" for="booking-email">
                  E-mail<span class="text-red-500">*</span>
                </label>
                <UInput id="booking-email" v-model="form.email" required />
              </div>
              <div class="space-y-1">
                <label class="text-sm font-medium" for="booking-phone">
                  Telefon<span class="text-red-500">*</span>
                </label>
                <UInput id="booking-phone" v-model="form.phone" required />
              </div>
              <div class="space-y-1">
                <label class="text-sm font-medium" for="booking-address">
                  Address<span class="text-red-500">*</span>
                </label>
                <UInput id="booking-address" v-model="form.address" required  />
              </div>

              <div class="space-y-1">
                <label class="text-sm font-medium" for="booking-notes">
                  Poznámka
                </label>
                <UTextarea
                  id="booking-notes"
                  v-model="form.notes"
                  placeholder="Volitelné"
                />
              </div>

              <div class="text-sm opacity-70">
                Termín: {{ modalSlot?.start.toLocaleString() }} –
                {{ modalSlot?.end.toLocaleString() }}
              </div>
            </div>

            <div class="flex gap-2 justify-end mt-4">
              <UButton variant="soft" type="button" @click="showModal = false">
                Zrušit
              </UButton>
              <UButton
                :loading="submitting"
                :disabled="!form.name"
                type="submit"
              >
                Odeslat
              </UButton>
            </div>
          </form>
        </UCard>
      </template>
    </UModal>
  </div>
</template>

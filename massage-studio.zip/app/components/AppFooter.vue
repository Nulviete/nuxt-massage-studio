<template>
  <div class="bg-green-500 h-16 text-center py-2">
    This is footer route name = {{ $route.name }}
  </div>
</template>

<script lang="ts" setup>

</script>

<style>

</style>
<template>
  <div class="min-h-dvh flex flex-col bg-[#237A1F]">
    <AppHeader />
    <div class="grow ">
      <slot />
    </div>
    <AppFooter />
  </div>
</template>
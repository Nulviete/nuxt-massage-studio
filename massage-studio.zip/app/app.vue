<template>
  <UApp :locale="pl">
    <NuxtLayout>
      <NuxtPage />
    </NuxtLayout>
  </UApp>
</template>

<script setup lang="ts">
import { cs, pl } from '@nuxt/ui/locale'

</script>

<style scoped>

</style>

<template>
    <div>
        <h1 class="bg-green-500">O...</h1>
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>
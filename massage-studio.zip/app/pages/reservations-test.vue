<template>
  <div>
    <bookingCalendar :user="user" />
  </div>
</template>

<script setup>
const user = useSupabaseUser();


</script>

<style lang="scss" scoped>

</style>
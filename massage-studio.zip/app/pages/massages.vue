<template>
    <div>
        <h1 class="bg-green-500">Massages</h1>
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>
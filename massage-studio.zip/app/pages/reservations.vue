<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { CalendarDate, toCalendar } from '@internationalized/date'

const today = new Date()
const modelValue = shallowRef(new CalendarDate(today.getUTCFullYear(), today.getMonth()+1, today.getDate()))


function getColorByDate(date: Date) {
  const isWeekend = date.getDay() % 2 == 0
  const isDayMeeting = date.getDay() % 3 == 0

  if (isWeekend) {
    return undefined
  }

  if (isDayMeeting) {
    return 'error'
  }

  return 'success'
}




</script>

<template>
  <div class="max-w-xl mx-auto p-4">
    <UCalendar 
      v-model="modelValue"
      :year-controls="false"
      :weekStartsOn="1"
      >
    <template #day="{ day }">
      <UChip :show="!!getColorByDate(day.toDate('UTC'))" :color="getColorByDate(day.toDate('UTC'))" size="2xs">
        {{ day.day }}
      </UChip>
    </template>
  </UCalendar>
  </div>
</template>

<style scoped>
/* optional styles */
</style>

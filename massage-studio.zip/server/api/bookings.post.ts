// server/api/bookings.post.ts
import { z } from 'zod'
import { getCalendarClient, overlap } from '../utils/gcal'
import { serverSupabaseUser } from '#supabase/server'   // <— přidat

const Body = z.object({
  name: z.string().min(1),
  email: z.string().email().optional(),
  start: z.string(), // ISO
  end: z.string(),   // ISO
  notes: z.string().optional()
})

export default defineEventHandler(async (event) => {
  try {
    const { calendar, calendarId, timezone } = await getCalendarClient()
    const body = Body.parse(await readBody(event))

    // 1) přihlášený uživatel
    const user = await serverSupabaseUser(event)   // null, pokud není přihlášený

    const start = new Date(body.start)
    const end   = new Date(body.end)

    // 2) kontrola kolizí
    const { overlaps, busy } = await overlap(start, end, calendarId)
    if (overlaps) {
      setResponseStatus(event, 409)
      return { ok: false, message: 'Termín je obsazený', busy }
    }

    // 3) extendedProperties.private s identitou uživatele
    const priv: Record<string, string> = {}
    if (user?.id)    priv.user_id = user.id
    if (user?.email) priv.user_email = user.email

    const summary = `Rezervace: ${body.name}`
    const description = [
      body.notes ? `Poznámka: ${body.notes}` : null,
      user?.email ? `Vytvořil: ${user.email}` : null
    ].filter(Boolean).join('\n')

    const insert = await calendar.events.insert({
      calendarId,
      requestBody: {
        summary,
        description,
        start: { dateTime: start.toISOString(), timeZone: timezone },
        end:   { dateTime: end.toISOString(),   timeZone: timezone },
        guestsCanSeeOtherGuests: true,
        extendedProperties: { private: priv },   // <— DŮLEŽITÉ
        // (volitelně) attendees: user?.email ? [{ email: user.email }] : undefined,
      },
      sendUpdates: 'none'
    })

    return { ok: true, id: insert.data.id }
  } catch (err: any) {
    console.error('[bookings.post] error:', err?.response?.data || err)
    setResponseStatus(event, Number(err?.code) || 500)
    return { ok: false, message: err?.message || 'Server error' }
  }
})
